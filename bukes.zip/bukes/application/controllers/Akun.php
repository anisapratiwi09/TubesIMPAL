<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Akun extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->library('form_validation');
    }

    public function index()
    {
        if ($this->session->userdata('email') == null) {
            $this->session->set_flashdata('message', '<div class="alert alert-warning" role="alert">Harus login terlebih dahulu.</div>');
            redirect('auth');
        }
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['title'] = 'Akun saya';
        $this->load->view('template/header', $data);
        $this->load->view('template/topbar');
        $this->load->view('akun/index', $data);
        $this->load->view('template/footer');
    }

    public function edit()
    {
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $this->form_validation->set_rules('name', 'Name', 'required|trim', ['required' => 'Nama tidak boleh kosong']);
        $this->form_validation->set_rules(
            'email',
            'Email',
            'required|trim|valid_email',
            [
                'required' => 'Email tidak boleh kosong',
                'valid_email' => 'Email tidak valid'
            ]
        );
        if ($this->form_validation->run() == false) {
            $this->session->set_flashdata('message', '<div class="alert alert-warning col-md-6" role="alert">Data tidak berhasil diubah</div>');
            redirect('akun');
        } else {
            $dataUpdate = [
                'name' => htmlspecialchars($this->input->post('name', true)),
                'email' => htmlspecialchars($this->input->post('email', true)),
                'no_hp' => htmlspecialchars($this->input->post('no_hp', true)),
                'alamat' => htmlspecialchars($this->input->post('alamat', true))
            ];
            if (
                $dataUpdate['name'] == $data['user']['name'] && $dataUpdate['email'] == $data['user']['email']
                && $dataUpdate['alamat'] == $data['user']['alamat'] && $dataUpdate['no_hp'] == $data['user']['no_hp']
            ) {
                $this->session->set_flashdata('message', '<div class="alert alert-warning col-md-6" role="alert">Tidak ada data yang diubah</div>');
                redirect('akun');
            }
            $this->db->where('id', $data['user']['id']);
            $this->db->update('user', $dataUpdate);
            $this->session->set_flashdata('message', '<div class="alert alert-success col-md-6" role="alert">Data berhasil di update</div>');
            redirect('akun');
        }
    }
}
