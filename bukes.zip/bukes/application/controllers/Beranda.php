<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Beranda extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('m_buku');
    }

    public function index()
    {
        $data['buku'] = $this->m_buku->getBuku();
        $data['title'] = 'Beranda';
        $this->load->view('template/header', $data);
        $this->load->view('template/topbar');
        $this->load->view('beranda', $data);
        $this->load->view('template/footer');
    }
}
