<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Buku extends CI_Controller
{
    public function detail($id)
    {
        $data['buku'] = $this->db->get_where('buku', ['id_buku' => $id])->row_array();
        $data['title'] = $data['buku']['namaBuku'];
        $this->load->view('template/header', $data);
        $this->load->view('template/topbar');
        $this->load->view('buku', $data);
        $this->load->view('template/footer');
    }
}
