<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Controller extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->helper('url');
		$this->load->library('session');
		$this->load->library('form_validation');
		$this->load->helper('form');
		$this->load->model('m_berandaa');
		$this->load->model('m_login');
		$this->load->model('M_profile');
		$this->load->model('User');
	}


	// public function login()
	// {
	// 	$this->form_validation->set_rules('username', 'Username', 'trim|required');
	// 	$this->form_validation->set_rules('password', 'Password', 'trim|required');

	// 	if ($this->form_validation->run() == false) {
	// 		$data['title'] = 'Login Page';
	// 		$this->load->view('login', $data);
	// 	} else {
	// 		// validasinya success
	// 		$this->aksi_login();
	// 	}
	// }

	// function aksi_login()
	// {

	// 	$username = $this->input->post('username');
	// 	$password = $this->input->post('password');
	// 	$where = array(
	// 		'username' => $username,
	// 		'password' => $password
	// 	);
	// 	$cek = $this->m_login->cek_login("users", $where)->num_rows();
	// 	if ($cek > 0) {
	// 		$data_session = array(
	// 			'nama' => $username,
	// 			'status' => "Login"
	// 		);
	// 		$this->session->set_userdata($data_session);
	// 		redirect(base_url("Controller/beranda/" . $username));
	// 	} else {
	// 		$this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">Username atau password salah!</div>');
	// 		redirect('Controller/login');
	// 	}
	// }

	public function beranda($username)
	{
		$result['users'] = $this->m_berandaa->showLogin($username);
		$result['title'] = 'Beranda';
		$this->load->view('beranda', $result);
	}

	public function keranjang()
	{
		$this->load->view('keranjang');
	}

	public function buku()
	{
		$this->load->view('buku');
	}

	public function akun()
	{
		$data['user'] = $this->db->get_where('users', ['username' => $this->session->userdata('nama')])->row_array();
		$data['title'] = 'Akun saya';
		$this->load->view('akun/template/akun_header', $data);
		$this->load->view('akun/index', $data);
		$this->load->view('akun/template/akun_footer');
	}

	public function editakun()
	{
		$this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email');
		$this->form_validation->set_rules('password', 'Password', 'trim|required');
		$data['user'] = $this->db->get_where('users', ['username' => $this->session->userdata('nama')])->row_array();

		if ($this->form_validation->run() == false) {

			$this->load->view('editakun', $data);
		} else {
			echo "data berhasil";
		}
	}
	public function pembayaran()
	{
		$this->load->view('pembayaran');
	}

	public function new()
	{
		$username = $this->input->post('username');
		$nama = $this->input->post('nama');
		$email = $this->input->post('email');
		$password = $this->input->post('password');

		$users = array(
			'username' => $username,
			'nama' => $nama,
			'email' => $email,
			'password' => $password
		);

		$this->User->new($users);
		header('Location: ' . base_url('Controller/beranda/' . $username));
	}


	function logout()
	{
		redirect(base_url('Controller/daftar'));
	}
}
