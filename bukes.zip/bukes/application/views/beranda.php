  <div class="">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div id="carouselExampleIndicators" class="carousel slide carousel-fade" data-ride="carousel">
            <ol class="carousel-indicators">
              <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"> </li>
              <li data-target="#carouselExampleIndicators" data-slide-to="1"> </li>
              <li data-target="#carouselExampleIndicators" data-slide-to="2"> </li>
            </ol>
            <div class="carousel-inner">
              <div class="carousel-item active border-bottom border-dark bg-light"> <img class="d-block mx-auto w-50 pt-3 pb-3" src="<?= base_url('assets/image/sisi1.jpg') ?>">
              </div>
              <div class="carousel-item border-bottom border-dark bg-light"> <img class="d-block mx-auto w-50 pt-3 pb-3" src="<?= base_url('assets/image/ruu1.jpg') ?>">
              </div>
              <div class="carousel-item border-bottom border-dark bg-light"> <img class="d-block mx-auto w-50 pt-3 pb-3" src="<?= base_url('assets/image/ruu2.jpg') ?>">
                <div class="carousel-caption">
                  <h5 class="m-0">Carousel</h5>
                  <p>with indicators</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="py-3">
    <div class="container">
      <div class="row">
        <div id="myBtnContainer">
          <button class="btn active" onclick="filterSelection('all')"> Show all</button>
          <button class="btn active" onclick="filterSelection('jaringan')">Jaringan</button>
          <button class="btn active" onclick="filterSelection('programming')">Programming</button>
          <button class="btn active" onclick="filterSelection('database')">Database</button>
        </div>
      </div>
    </div>
  </div>
  <div class="py-2">
    <div class="container">
      <div class="row">
        <?php foreach ($buku as $b) : ?>
          <div class="column <?= $b['kategori'] ?> col-sm-3">
            <div class="card text-center">
              <a href="<?= base_url('buku/detail/') . $b['id_buku'] ?>"> <img href="" class="card-img-top" src="<?= base_url('assets/img/') . $b['img'] ?>"></a>
              <a class="text-reset" href="<?= base_url('buku/detail/') . $b['id_buku'] ?>">
                <h5 class="card-title"><?= $b['namaBuku'] ?></h5>
              </a>
              <p class="card-text"><?= $b['hargaBuku'] ?></p>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
      <!-- END GRID -->
    </div>
  </div>