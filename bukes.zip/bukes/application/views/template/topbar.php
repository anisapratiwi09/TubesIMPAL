<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar14" aria-controls="navbar14" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbar14">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item"> <a class="nav-link" href="<?= base_url('beranda') ?>">Beranda</a> </li>
                <li class="nav-item"> <a class="nav-link" href="#">Kategori</a> </li>
                <li class="nav-item"> <a class="nav-link" href="#">Tentang</a> </li>
            </ul>
        </div>
        <p class="d-none d-md-block lead mb-0 text-white"> <a class="text-reset text-decoration-none" href="<?= base_url('beranda') ?>"><i class="fa d-inline fa-lg fa-book"></i>&nbsp;BUKES</p></a>
        <div class="collapse navbar-collapse" id="navbar14">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item mx-1"> <a class="nav-link" href="<?= base_url('akun') ?>">
                        <i class="fa fa-user fa-fw fa-lg text-light"></i>
                    </a> </li>
                <li class="nav-item mx-1"> <a class="nav-link" href="#">
                        <i class="fa fa-shopping-bag fa-fw fa-lg text-light"></i>
                    </a> </li>
                <li class="nav-item mx-1"> <a class="nav-link" href="#">
                        <i class="fa fa-question-circle fa-fw fa-lg text-light"></i>
                    </a> </li>
            </ul>
        </div>
    </div>
</nav>