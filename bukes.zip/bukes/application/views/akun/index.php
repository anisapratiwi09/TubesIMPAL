  <div class="py-5" style="">
    <div class="container">
      <div class="row">
        <div class="col-3">
          <ul class="nav nav-pills flex-column">
            <li class="nav-item"> <a href="#" class="active nav-link" data-toggle="pill" data-target="#tabone">Akun saya</a></li>
            <li class="nav-item"> <a href="#" class="nav-link" data-toggle="pill" data-target="#tabtwo">Keranjang Saya</a> </li>
            <li class="nav-item"> <a href="<?= base_url('auth/logout') ?>" class="nav-link">Log out</a> </li>
          </ul>
        </div>
        <div class="col-9">
          <div class="tab-content">
            <div class="tab-pane fade show active" id="tabone" role="tabpanel">
              <?= $this->session->flashdata('message'); ?>
              <form method="post" action="<?= base_url('akun/edit') ?>" id="edit_form">
                <fieldset id="editField" disabled>
                  <div class="form-group">
                    <label for="name">Nama lengkap</label>
                    <input type="text" name="name" id="name" class="form-control col-md-6" placeholder="Masukkan nama" value="<?= $user['name'] ?>">
                  </div>
                  <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" name="email" id="email" class="form-control col-md-6" placeholder="Masukkan email" value="<?= $user['email'] ?>">
                  </div>
                  <div class="form-row">
                    <div class="form-group col-md-3">
                      <label for="jenis_kelamin">Jenis kelamin</label>
                      <input type="text" name="jenis_kelamin" id="jenis_kelamin" class="form-control" value="<?= $user['jenis_kelamin'] ?>" readonly>
                    </div>
                    <div class="form-group col-md-3">
                      <label for="no_hp">No hp</label>
                      <input type="text" name="no_hp" id="no_hp" class="form-control" placeholder="kosong" value="<?= $user['no_hp'] ?>">
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="name">Alamat</label>
                    <input type="text" name="alamat" id="alamat" class="form-control col-md-6" placeholder="Kosong" value="<?= $user['alamat'] ?>">
                  </div>
                  <button type="submit" id="editSubmit" hidden></button>
                  <p class="card-text"><small class="text-muted">Member sejak <?= date('d F Y', $user['date_created']) ?></small></p>
                  <p></p>
                </fieldset>
              </form>
              <button type="submit" class="btn btn-orimary text-light btn-sm active" id="edit" onclick="edit()">Edit</button>
            </div>
            <div class="tab-pane fade" id="tabtwo" role="tabpanel">
              <p class=""></p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>