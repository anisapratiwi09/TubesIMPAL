<div class="py-5 text-center text-white bg-light">
  <div class="container">
    <div class="row">
      <div class="p-5 col-lg-6 col-10 mx-auto border bg-dark">
        <h2 class="mb-4">Login</h2>
        <?= $this->session->flashdata('message'); ?>
        <form action="<?php echo base_url('auth'); ?>" method="post">
          <div class="form-group">
            <input class="form-control" type="email" name="email" placeholder="Email" value="<?= set_value('email'); ?>">
            <?= form_error('email', '<small class="text-danger pl-3">', '</small>'); ?>
          </div>
          <div class="form-group">
            <input type="password" name="password" class="form-control" placeholder="Kata sandi" id="form15">
            <?= form_error('password', '<small class="text-danger pl-3">', '</small>'); ?>
            <small class="form-text text-muted text-right">
              <div class="text-right">
                <a class="small" href="<?= base_url('auth/registration'); ?>">Belum punya akun?</a>
              </div>
            </small> </div> <button type="submit" class="btn btn-light text-dark">Login</button>
        </form>
      </div>
    </div>
  </div>
</div>