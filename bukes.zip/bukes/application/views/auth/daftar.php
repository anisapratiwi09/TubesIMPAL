  <div class="py-5 text-center text-white bg-light">
    <div class="container">
      <div class="row">
        <div class="p-5 col-lg-6 col-10 mx-auto border bg-dark">
          <h2 class="mb-4">Anda belum punya akun ?<br>Silahkan daftar</h2>
          <form method="post" action="<?php echo base_url('auth/registration') ?>">
            <div class="form-group">
              <input type="text" class="form-control" placeholder="Nama lengkap" name="name" id="form13" value="<?= set_value('name'); ?>">
              <?= form_error('name', '<small class="text-danger pl-3">', '</small>'); ?>
            </div>
            <div class="form-group">
              <input type="email" class="form-control" placeholder="Email" name="email" id="form15" value="<?= set_value('email'); ?>">
              <?= form_error('email', '<small class="text-danger pl-3">', '</small>'); ?>
            </div>
            <div class="form-group">
              <select class="custom-select" name="jenis_kelamin" id="form19">
                <option value="" selected>Pilih Jenis kelamin</option>
                <option value="Laki-laki">Laki-laki</option>
                <option value="Perempuan">Perempuan</option>
              </select>
              <?= form_error('jenis_kelamin', '<small class="text-danger pl-3">', '</small>'); ?>
            </div>
            <div class="form-group">
              <input type="password" class="form-control" placeholder="Kata sandi" name="password" id="form16">
              <?= form_error('password', '<small class="text-danger pl-3">', '</small>'); ?>
            </div>
            <div class="form-group">
              <input type="password" class="form-control" placeholder="Ulangi kata sandi" name="password2" id="form17">
              <?= form_error('password2', '<small class="text-danger pl-3">', '</small>'); ?>
            </div>
            <small class="form-text text-muted text-right">
              <div class="text-right">
                <a class="small" href="<?= base_url('auth'); ?>">Sudah punya akun?</a>
              </div>
            </small>
            <button type="submit" class="btn btn-light text-dark" id="daftar">Daftar</button>
          </form>
        </div>
      </div>
    </div>
  </div>