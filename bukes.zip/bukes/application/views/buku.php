  <div class="border-bottom py-0 pt-5" style="">
    <div class="container">
      <div class="row">
        <div class="col-md-4" style=""><img class="d-block img-fluid float-left" src="<?= base_url('assets/img/') . $buku['img'] ?>"></div>
        <div class="col-md-4" style="">
          <h2 class=""><br><br><b><?= $buku['namaBuku'] ?></b></h2>
          <h5 class=""><b><?= $buku['pengarang'] ?></b></h5>
        </div>
        <div class="col-lg-4 p-3">
          <div class="card text-center">
            <div class="card-header p-3">
              <h3>Soft Copy</h3>
              <h2> <b>Rp <?= $buku['hargaBuku'] ?></b></h2>
            </div>
            <div class="card-body p-3" style="">
              <a class="btn text-light btn-dark btn-block active" href="#">Beli Sekarang</a> </div>
            <div class="card-body p-3" style="">
              <a class="btn btn-dark btn-block active" href="#">Tambah Keranjang&nbsp;</a> </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="border-bottom text-dark" style="">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <ul class="nav nav-pills border-bottom">
            <li class="nav-item text-dark"> <a href="" class="nav-link text-dark active" data-toggle="pill" data-target="#tabone">Deskripsi</a> </li>
            <li class="nav-item" style=""> <a class="nav-link text-dark" href="" data-toggle="pill" data-target="#tabtwo">Detail</a> </li>
            <li class="nav-item text-dark"> <a href="" class="nav-link text-dark" data-toggle="pill" data-target="#tabthree">Review</a> </li>
          </ul>
          <div class="tab-content mt-2">
            <div class="tab-pane fade show active" id="tabone" role="tabpanel">
              <p class=""><?= $buku['synopsis'] ?></p>
            </div>
            <div class="tab-pane fade" id="tabtwo" role="tabpanel">
              <p class="">Jumlah Halaman 400&nbsp;<br>Tanggal Terbit 11 Mar 2019&nbsp;<br>ISBN 9786020623399&nbsp;<br>Bahasa Indonesia&nbsp;<br>Penerbit Gramedia Pustaka Utama&nbsp;<br>Berat 0.300 kg&nbsp;<br>Lebar 20 cm&nbsp;<br>Panjang 13.5 cm</p>
            </div>
            <div class="tab-pane fade" id="tabthree" role="tabpanel">
              <p class="">0</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>