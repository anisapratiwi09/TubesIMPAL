<?php
defined('BASEPATH') or exit('No direct script access allowed');
class M_buku extends CI_Model
{
    public function getBuku()
    {
        $query =  $this->db->get_where('buku', ['available' => 1])->result_array();
        return $query;
    }
}
