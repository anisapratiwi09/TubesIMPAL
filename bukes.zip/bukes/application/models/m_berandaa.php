<?php
defined('BASEPATH') or exit('No direct script access allowed');

class M_berandaa extends CI_Model
{
	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}
	/*function showtweet($username){
		$this->db->where('username',$username);
		$query = $this->db->query("select * from twitter where username= '$username'");
		return $query->result();

		
		//return $this->db->$->result_array();

	}
	function savetweet($tweet){
		$query = "insert into tweet values ('$tweet')";
		$this->db->query($query);
	}*/

	/*	function input_data($data,$table){
		$this->db->insert($table,$data);
	}*/

	function showLogin($email)
	{
		$this->db->where('email', $email);
		$this->db->from('user');
		return $this->db->get()->row();
	}
}
