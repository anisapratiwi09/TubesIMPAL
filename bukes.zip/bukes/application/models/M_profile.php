<?php
defined('BASEPATH') or exit('No direct script access allowed');
class M_profile extends CI_Model
{

	public function getDataUser($email)
	{
		$this->db->where('email', $email);
		$this->db->from('user');
		return $this->db->get()->row();
		//return $this->db->get('user')->result_array();

	}

	public function edit($username)
	{

		$name = $this->input->post('name');
		$bio = $this->input->post('bio');
		$lokasi = $this->input->post('lokasi');
		$website = $this->input->post('website');
		$birth = $this->input->post('birth');

		$user = array(
			'name' => $name,
			'bio' => $bio,
			'lokasi' => $lokasi,
			'website' => $website,
			'birth' => $birth,
		);
		$this->db->where('username', $username);
		$this->db->update('user', $user);
	}
}
