-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 29, 2019 at 04:06 PM
-- Server version: 10.3.16-MariaDB
-- PHP Version: 7.3.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_bukes`
--

-- --------------------------------------------------------

--
-- Table structure for table `buku`
--

CREATE TABLE `buku` (
  `id_buku` varchar(5) NOT NULL,
  `namaBuku` varchar(30) DEFAULT NULL,
  `pengarang` varchar(50) DEFAULT NULL,
  `jumlahHalaman` int(11) NOT NULL,
  `tglTerbit` date NOT NULL,
  `hargaBuku` int(11) DEFAULT NULL,
  `penerbit` varchar(30) DEFAULT NULL,
  `ISBN` varchar(100) NOT NULL,
  `bahasa` varchar(50) NOT NULL,
  `synopsis` varchar(300) DEFAULT NULL,
  `berat` int(11) NOT NULL,
  `lebar` int(11) NOT NULL,
  `panjang` int(11) NOT NULL,
  `kategori` varchar(20) NOT NULL,
  `img` varchar(64) NOT NULL DEFAULT 'default.jpg',
  `available` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `buku`
--

INSERT INTO `buku` (`id_buku`, `namaBuku`, `pengarang`, `jumlahHalaman`, `tglTerbit`, `hargaBuku`, `penerbit`, `ISBN`, `bahasa`, `synopsis`, `berat`, `lebar`, `panjang`, `kategori`, `img`, `available`) VALUES
('BOOK1', 'Komputer & jaringan', 'jesbus', 0, '0000-00-00', 80000, 'kampus', '', '', 'mengajarkan komputer', 0, 0, 0, 'jaringan', 'jaringan1.jpg', 1),
('BOOK2', 'Belajar database', 'susanto', 0, '0000-00-00', 90000, 'informatics', '', '', 'belajar database dengan mudah', 0, 0, 0, 'database', 'database1.jpg', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `buku`
--
ALTER TABLE `buku`
  ADD PRIMARY KEY (`id_buku`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
